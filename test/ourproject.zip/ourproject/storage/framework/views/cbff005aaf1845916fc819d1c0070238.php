<link href="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/style.min.css" rel="stylesheet" />
<link href="<?php echo e(asset('/')); ?>/assets/backend/css/styles.css" rel="stylesheet" />
<script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
<?php /**PATH G:\batch-25\xampp25\htdocs\batch25\day-48\ourproject\resources\views/backend/includes/style.blade.php ENDPATH**/ ?>