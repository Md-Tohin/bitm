<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
<script src="<?php echo e(asset('/')); ?>/assets/backend/js/scripts.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
<script src="<?php echo e(asset('/')); ?>/assets/backend/assets/demo/chart-area-demo.js"></script>
<script src="<?php echo e(asset('/')); ?>/assets/backend/assets/demo/chart-bar-demo.js"></script>
<script src="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/umd/simple-datatables.min.js" crossorigin="anonymous"></script>
<script src="<?php echo e(asset('/')); ?>/assets/backend/js/datatables-simple-demo.js"></script>
<?php /**PATH G:\batch-25\xampp25\htdocs\batch25\day-48\ourproject\resources\views/backend/includes/script.blade.php ENDPATH**/ ?>