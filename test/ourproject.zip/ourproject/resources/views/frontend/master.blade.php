
@include('frontend.include.header')

@yield('content')

@include('frontend.include.footer')
